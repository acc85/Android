package org.helpapaw.helpapaw

class Constants {

    companion object {
        const val BACKENDLESS_APP_ID: String = "BDCD56B9-351A-E067-FFA4-9EA9CF2F4000"
        const val BACKENDLESS_REST_API_KEY: String = "FF1687C9-961B-4388-FFF2-0C8BDC5DFB00"
        const val BACKENDLESS_ANDROID_API_KEY = "FF1687C9-961B-4388-FFF2-0C8BDC5DFB00"
    }
}