package org.helpapaw.helpapaw.viewmodels

import androidx.databinding.BaseObservable
import androidx.databinding.Bindable
import androidx.lifecycle.ViewModel

class AboutViewwModel: BaseObservable() {

    @Bindable

}
