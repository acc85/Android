package org.helpapaw.helpapaw.signaldetails

interface StatusCallback {
    fun onRequestStatusChange(status: Int)
}
