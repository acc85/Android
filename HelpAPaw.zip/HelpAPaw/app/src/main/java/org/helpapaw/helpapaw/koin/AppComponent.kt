package org.helpapaw.helpapaw.koin

import org.koin.core.KoinComponent

class AppComponent:KoinComponent{


}